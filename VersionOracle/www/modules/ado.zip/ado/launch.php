<?php
/**
 * CLASE QUE INICIA EL MODULO DE ADODB
 * @autor Jorge Tenorio
 * @since 24/03/2010
 */

 class Ado{

    private $server;
    private $user;
    private $pwd;
    private $dbname;
    private $connSQL;
    private $engine;

    public function __construct(){
        $this->loadCredentials();
        $this->connect();
    }

    private function loadCredentials(){
        //cargar el archivo /conf/dataBase.conf
       $data = file($_SESSION["path"].'/conf/dataBase.conf');
       $campo =0;
       for($i=0;$i<count($data);$i++){
           if(substr($data[$i],0,1)!='#'){
               $data[$i] = trim($data[$i]);
                switch($campo){
                    case 0:
                        $this->server = $data[$i];
                        break;
                    case 1:
                        $this->user = $data[$i];
                        break;
                    case 2:
                        $this->pwd = $data[$i];
                        break;
                    case 3:
                        $this->dbname = $data[$i];
                        break;
                    case 4:
                        $this->engine = $data[$i];
                        break;
                }
                $campo++;
           }
       }
    }



    private function connect(){
        include_once($_SESSION["path"].'/modules/ado/adodb/adodb.inc.php');
        /*$strConn = $this->engine .'://'. $this->user .':'.$this->pwd . '@' . $this->server . '/' .  $this->dbname  . '?persist';
        $this->connSQL = ADONewConnection($strConn);
        $this->connSQL->SetFetchMode(ADODB_FETCH_ASSOC);
        $this->connSQL->debug = false;*/

        //ORACLE 
        $this->connSQL = NewADOConnection($this->engine);
        $this->connSQL->Connect($this->server, $this->user, $this->pwd,$this->dbname);
        $this->connSQL->SetFetchMode(ADODB_FETCH_ASSOC);
        //$this->connSQL->debug = false;

    }

    

    public function query($sql, $showError = TRUE){
        //echo $sql = utf8_decode(trim($sql));
        //echo $sql;
        echo $sql = htmlentities(trim($sql));
		//NEW CODE FOR ORACLE (jtenorio)
        
        $recordSet = $this->connSQL->Execute($sql);
        if (!$recordSet){
		//echo $this->connSQL->ErrorMsg();
            if($showError)
		echo '<p class="error">'.$this->connSQL->ErrorMsg().'</p>';
	return array('Error'=>$this->connSQL->ErrorMsg());
        }else{
           if($recordSet->RecordCount() > 0){

            $temp = $recordSet->GetRows();
		
		foreach($temp as $field =>  $value){
			foreach($value as $columna => $val){
                            //$temp2[$field][$columna] = utf8_decode($val);
                            $temp2[$field][$columna] = html_entity_decode($val);
			}
			
		}
		return $temp2;
	     }
           else
               return array();
        }

    }


 
 }

?>
